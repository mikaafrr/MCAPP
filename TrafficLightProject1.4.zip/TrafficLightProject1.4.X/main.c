#include <xc.h>
#include "config.h"

// Function declarations
void initSysPins(void);
void initSysExtInt(void);
void initLCD(void);
void initADC(void);
void initSysTimer(void);

void greenLight(void);
void yellowLight(void);
void redLightGreenMan(void);
void resetLights(void);

void dspTask_OnSevSeg(void);

void playInitialTune(void);

unsigned int adcDayNight_GetConversion(void);
void lcdCreateCustomChars(void);
void displayStandingStickman(void);
void displayGreenLightText(void);
void clearLCD(void);  // Add the declaration here

// External variables
extern int greenDone;
extern int yellowDone;
extern int redDone;

unsigned int count;
unsigned int pedDet(void);
unsigned int dayNight;

void main(void) 
{
    
    initADC(); 
    initSysPins(); 
    initSysExtInt(); 
    initSysTimer();  
    initLCD();
    lcdCreateCustomChars(); // Initialize custom characters
    PORTD = 0; 
    PORTA = 0; 
    PORTAbits.RA2 = 1;
    PORTAbits.RA3 = 1;
     while(1)
    {
         dayNight = adcDayNight_GetConversion();
         if (dayNight > 128)
         {
             PORTAbits.RA4 = 1;
         }
         else if (dayNight < 128)
         {
            PORTAbits.RA4 = 0;
         }
         
         
        displayStandingStickman(); // Display standing stickman during green light
        if (greenDone == 0){
            displayGreenLightText();
        }
        if (yellowDone == 1) { 
            dspTask_OnSevSeg();
        }
        if (pedDet() == 1 && (greenDone == 0)) {
            greenLight();
        }
        if ((greenDone == 1) && (yellowDone == 0)) {
            yellowLight();
        }
        if ((greenDone == 1) && (yellowDone == 1)) {
            playInitialTune();  
            redLightGreenMan();
        }
        if ((greenDone == 1) && (yellowDone == 1) && (redDone == 1)) {
            resetLights();
            clearLCD(); // Clear LCD during reset
        }
    }
}

void initSysPins(void) 
{
    ANSELA = 0b00000000;
    TRISA = 0b00000000;

    ANSELB = 0b00000000;
    TRISB = 0b00000011;

    ANSELC = 0b00000000;
    TRISC = 0b10000000;

    ANSELD = 0b01000000;
    TRISD = 0b11000000;

    ANSELE = 0b00000000;
    TRISE = 0b11111100;
}
