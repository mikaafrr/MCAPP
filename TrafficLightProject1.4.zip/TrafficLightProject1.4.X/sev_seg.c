#include <xc.h>
#include "config.h"

// Seven-segment display encoding table
// Each entry corresponds to a digit (0-9) and a blank display
const unsigned char segTable[11] ={
    0b11000000, // 0
    0b11111001, // 1
    0b10100100, // 2
    0b10110000, // 3
    0b10011001, // 4
    0b10010010, // 5
    0b10000010, // 6
    0b11111000, // 7
    0b10000000, // 8
    0b10011000, // 9
    0b11111111  // Blank
};

// Function to display a two-digit number on a seven-segment display
void seg_DispAll(unsigned int count) {
    unsigned int MSB; // Most significant digit
    unsigned int LSB; // Least significant digit
    
    // Calculate the most significant and least significant digits
    MSB = count / 10;
    LSB = count % 10;

    // Display the least significant digit
    PORTDbits.RD4 = 1;  // Enable LSB digit
    PORTDbits.RD5 = 0;  // Disable MSB digit
    PORTC = segTable[LSB];  // Send LSB to PORTC
    __delay_ms(5);  // Delay of 5ms
    PORTC = segTable[10];  // Turn off the display to prevent ghosting

    // Display the most significant digit
    PORTDbits.RD5 = 1;  // Enable MSB digit
    PORTDbits.RD4 = 0;  // Disable LSB digit
    PORTC = segTable[MSB];  // Send MSB to PORTC
    __delay_ms(5);  // Delay of 5ms
    PORTC = segTable[10];  // Turn off the display to prevent ghosting
}