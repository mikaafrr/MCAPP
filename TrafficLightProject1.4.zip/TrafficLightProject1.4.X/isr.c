#include <xc.h>
#include "config.h"

// Function Declarations:
// - Defined in other file(s):
void extint_setElderlyDetect(void);
void tmr1_HandleTimerInterrupt(void);

void __interrupt() isr(void) {
    if (PIR0bits.INTF == 1) { // Check the INT flag
        PIR0bits.INTF = 0; // Clear the INT flag
        extint_setElderlyDetect();
    }
    
    if (PIR4bits.TMR1IF == 1) { // Check the Timer1 interrupt flag
        PIR4bits.TMR1IF = 0; // Clear the Timer1 interrupt flag
        tmr1_HandleTimerInterrupt();
    }
}
