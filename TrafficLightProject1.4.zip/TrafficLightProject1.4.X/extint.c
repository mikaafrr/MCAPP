#include <xc.h>
#include "config.h"



// Global Variable:
// Indicates whether an elderly person has been detected
unsigned int elderlyDetect = 0; 

// Function to initialize the system's external interrupt
void initSysExtInt(void)
{
    INTCONbits.GIE = 0; // Disable Global Interrupt
    PIR0bits.INTF = 0; // Clear external INT flag
    INTPPS = 0x09; // Map external INT to RB1
    INTCONbits.INTEDG = 1; // Configure for rising edge interrupt
    PIE0bits.INTE = 1; // Enable external INT interrupt
    INTCONbits.GIE = 1; // Enable Global Interrupt
}

// Function to set the elderly detection flag
void extint_setElderlyDetect(void)
{
    elderlyDetect = 1; // Set the elderly detection flag to 1
}
