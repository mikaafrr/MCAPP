#include <xc.h>
#include "config.h"

// Function prototypes for Timer1 functions
void tmr1_StartTone(void);
void tmr1_StopTone(void);
void updateToneAndDisplay(void);

// Initialize status flags for light states
int greenDone = 0;
int yellowDone = 0;
int redDone = 0;

// Block flag for pressure detection
int blockPressure = 0;  
int blockDayNight = 0;
// Block flag for elderly detection
int blockElderly = 0;   



// Initialize reset detection flag
int resetDetect = 0;

// Initialize light countdown timers
unsigned int greenLightCount = 5;
unsigned int yellowLightCount = 5;
unsigned int redLightCount = 320;  // Duration for the red light (5 seconds)

// Function prototypes for external interrupts and ADC conversion
unsigned int extint_getElderlyDetect(void);
unsigned int adc_GetConversion(void);
unsigned int adcDayNight_GetConversion(void);

// Function prototype for seven-segment display task
void seg_DispAll(unsigned int count);

// External variables indicating pedestrian and elderly detection
extern unsigned int detect;
extern unsigned int elderlyDetect;

void lcdWriteDspData(char x);
void lcdCtrl_SetPos(char row, char col);
void displayStandingStickman(void);
void displayRightWalkStickman(void);
void displayLeftWalkStickman(void);
void displayGreenLightText(void);
void displayRedLightText(void);
void displayYellowLightText(void);
void clearLCD(void);

// Function to handle green light timing and state
void greenLight(void) {
    greenLightCount = greenLightCount - 1;
    __delay_ms(1000);  // Delay for 1 second
    displayGreenLightText();
    displayStandingStickman();
    if (greenLightCount == 0) {
        PORTAbits.RA2 = 0;  // Turn off green light
        detect = 0;         // Reset pedestrian detect flag
        greenDone = 1;      // Set green light done flag
    }
}

// Function to handle yellow light timing and state
void yellowLight(void) {
    unsigned int result = adc_GetConversion();  // Get ADC conversion result
    unsigned int dayNight = adcDayNight_GetConversion();
    if (((elderlyDetect == 1) && (blockElderly == 0)) || ((result > 128) && (blockPressure == 0))) {
        redLightCount = redLightCount + 320;  // Extend red light duration if conditions met
        blockPressure = 1;  // Set block pressure flag
        blockElderly = 1;   // Set block elderly flag
    }
    
     if ((dayNight > 128) && (blockDayNight == 0)){ // >128 Night time 
            redLightCount = redLightCount - 128;
            blockDayNight = 1;
        }
    
    PORTAbits.RA2 = 0;  // Turn off green light
    PORTAbits.RA1 = 1;
    PORTAbits.RA3 = 1;// Turn on yellow light
    yellowLightCount = yellowLightCount - 1;
    __delay_ms(1000);  // Delay for 1 second
    displayYellowLightText();
    displayStandingStickman(); // Display standing stickman during yellow light
    if (yellowLightCount == 0) {
        PORTAbits.RA1 = 0;  // Turn off yellow light
        PORTAbits.RA3 = 0;
        yellowDone = 1;     // Set yellow light done flag
    }
}

// Function to handle red light and green pedestrian signal timing and state
void redLightGreenMan(void) {
    clearLCD();
    displayRedLightText();
    PORTAbits.RA0 = 1;  // Turn on red light
    PORTAbits.RA5 = 1;  // Turn on green pedestrian signal

    while (redLightCount > 0) {
        if ((redLightCount / 64) % 2 == 0) {
            displayLeftWalkStickman();
        } 
        else {
            displayRightWalkStickman();
        }
        redLightCount = redLightCount - 1;
        updateToneAndDisplay();
        
        __delay_ms(3.90625);  // Delay for 7.8125ms
    }

    PORTAbits.RA0 = 0; // Turn off red light
    PORTAbits.RA5 = 0; // Turn off green pedestrian signal
    redDone = 1;       // Set red light done flag
    elderlyDetect = 0; // Reset elderly detection flag
    clearLCD();        // Clear LCD during red light
}

// Function to reset all light states and timers
void resetLights(void) {
    greenLightCount = 5;
    yellowLightCount = 5;
    redLightCount = 320;
    greenDone = 0;
    yellowDone = 0;
    redDone = 0;
    PORTAbits.RA3 = 1;
    PORTAbits.RA2 = 1;  // Turn on green light
    blockPressure = 0;  // Reset block pressure flag
    blockDayNight = 0;
    blockElderly = 0;   // Reset block elderly flag
    clearLCD();         // Clear LCD during reset
}

// Function to display the remaining red light time on a seven-segment display
void dspTask_OnSevSeg(void) {
    unsigned int count;
    count = redLightCount / 64;  // Calculate remaining time in seconds
    seg_DispAll(count + 1);      // Display time on seven-segment display
}


