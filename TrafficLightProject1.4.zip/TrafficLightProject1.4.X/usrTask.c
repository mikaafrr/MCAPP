#include <xc.h>
#include "config.h"

// Define SW0 as switch connected to RB0 pin
#define SW0 PORTBbits.RB0

// Variable to detect pedestrian button press
unsigned int detect = 0;

// Function to detect pedestrian button press
unsigned int pedDet(void)
{
    // Check if switch is pressed
    if (SW0 == 0)
    {
        // Debounce delay
        __delay_ms(10);
        
        // Check switch state again after delay
        if (SW0 == 0)
        {
            // Wait until switch is released
            while(SW0 == 0);
            
            // Set detect flag to indicate pedestrian button press
            detect = 1;
        }
    }
    
    // Return the detection value
    return detect;
}
