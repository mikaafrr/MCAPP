#include <xc.h>
#include "config.h"

// Function to initialize the ADC
void initADC(void)
{
    ADREF = 0b00000000;  // Set VREF+ and VREF- to VSS and VDD
    ADCLK = 0b00000011;  // Set TAD = 2 us (ADC clock period)
    ADACQ = 0b00000000;  // Set acquisition time to be manually inserted
    ADCON0 = 0b10000000; // Enable ADC, set to single conversion mode, use FOSC clock, result is left justified
}

// Function to perform an ADC conversion and get the result
unsigned int adc_GetConversion(void)
{
    unsigned char result;
    ADPCH = 0b00011110;  // Select channel ANA0 for input at RA0
    __delay_us(2);       // Add 2 us acquisition time manually
    ADCON0bits.ADGO = 1; // Start conversion
    while (ADCON0bits.ADGO == 1); // Wait for conversion to complete
    result = ADRESH;     // Get the result from the upper 8 bits
    return (result);     // Return the result
}

unsigned int adcDayNight_GetConversion(void){
    unsigned char result;
    ADPCH = 0b00011111;
    __delay_us(2);
    ADCON0bits.ADGO = 1;
    while (ADCON0bits.ADGO == 1);
    result = ADRESH;
    return (result);
}
