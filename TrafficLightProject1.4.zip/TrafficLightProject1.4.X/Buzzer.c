# include "config.h"
#include <xc.h>

void dspTask_OnSevSeg(void);

    void playInitialTune(void) {
        for (unsigned int j = 0; j < 48; j++) {
            PORTBbits.RB3 = 1;
            __delay_us(165);  
            PORTBbits.RB3 = 0;
            __delay_us(165);
        }

        for (unsigned int j = 0; j < 73; j++) {
            PORTBbits.RB3 = 1;
            __delay_us(268);  
            PORTBbits.RB3 = 0;
            __delay_us(268);
        }

        for (unsigned int j = 0; j < 11; j++) {
            PORTBbits.RB3 = 1;
            __delay_us(310);  
            PORTBbits.RB3 = 0;
            __delay_us(310);
        }

        for (unsigned int j = 0; j < 18; j++) {
            PORTBbits.RB3 = 1;
            __delay_us(334);  
            PORTBbits.RB3 = 0;
            __delay_us(334);
        }

        for (unsigned int j = 0; j < 29; j++) {
            PORTBbits.RB3 = 1;
            __delay_us(377);  
            PORTBbits.RB3 = 0;
            __delay_us(377);
        }

        for (unsigned int j = 0; j < 10.4; j++) {
            PORTBbits.RB3 = 1;
            __delay_us(432);  
            PORTBbits.RB3 = 0;
            __delay_us(432);
        }

        for (unsigned int j = 0; j < 8.7; j++) {
            PORTBbits.RB3 = 1;
            __delay_us(461);  
            PORTBbits.RB3 = 0;
            __delay_us(461);
        }

        for (unsigned int j = 0; j < 10.6; j++) {
            PORTBbits.RB3 = 1;
            __delay_us(565);  
            PORTBbits.RB3 = 0;
            __delay_us(565);
        }

    }
    
    void updateToneAndDisplay(void) {
    static unsigned int toneStep = 0;
    static unsigned int toneCounter = 0;

    // Generate the tone
    if (toneCounter % 4 == 0) { // Adjust the frequency by changing the modulus value
        if (toneStep % 2 == 0) {
            PORTBbits.RB3 = 1;
            __delay_us(100);  
            PORTBbits.RB3 = 0;
            __delay_us(100);
            PORTBbits.RB3 = 1;
            __delay_us(100);  
            PORTBbits.RB3 = 0;
            __delay_us(100);
            PORTBbits.RB3 = 1;
            __delay_us(100);  
            PORTBbits.RB3 = 0;
            __delay_us(100);
            PORTBbits.RB3 = 1;
            __delay_us(100);  
            PORTBbits.RB3 = 0;
            __delay_us(100);
        } else {
            PORTBbits.RB3 = 0;
        }
        toneStep++;
    }
    toneCounter++;

    // Update the seven-segment display
    dspTask_OnSevSeg();
}
