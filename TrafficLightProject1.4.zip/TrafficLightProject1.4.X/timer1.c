#include <xc.h>
#include "config.h"

// Declare the dspTask_OnSevSeg function
void dspTask_OnSevSeg(void);

// Declare redLightCount as extern to make it accessible
extern unsigned int redLightCount;

#define TONE_HIGH_HALF_PERIOD 200 // Adjust these values to fine-tune the tone
#define TONE_LOW_HALF_PERIOD  300
#define DISPLAY_UPDATE_PERIOD 256 // Update display every 256 interrupts (approximately every 2 seconds)

unsigned int tmr1_TotalReqdCount;
unsigned int tmr1_RunCount;
unsigned int toneStep = 0;

void initSysTimer(void) {
    INTCONbits.GIE = 0;
    INTCONbits.PEIE = 1;
    T1CON = 0b00000010; // Disable Timer1 first. Pre-scaler is 1
    T1CLK = 0b00000001;
    PIE4bits.TMR1IE = 1; // Enable Timer1 interrupt
    PIR4bits.TMR1IF = 0;
    INTCONbits.GIE = 1;
}

void tmr1_StartToneAndCountdown(void) {
    unsigned int preload_value;
    preload_value = (65536 - TONE_HIGH_HALF_PERIOD);
    // Write to the Timer1 register
    TMR1H = (unsigned char) (preload_value >> 8);
    TMR1L = (unsigned char) preload_value;
    tmr1_TotalReqdCount = 1280; // Set for 5 seconds (1280 * 7.8125ms = 10 seconds)
    tmr1_RunCount = 0;
    T1CONbits.TMR1ON = 1; // Start timer
}

void tmr1_StopTone(void) {
    T1CONbits.TMR1ON = 0; // Stop Timer1
    PORTBbits.RB3 = 0;    // Ensure the speaker is off
}

void tmr1_HandleTimerInterrupt(void) {
    unsigned int preload_value;
    if (toneStep % 2 == 0) {
        preload_value = (65536 - TONE_HIGH_HALF_PERIOD);
    } else {
        preload_value = (65536 - TONE_LOW_HALF_PERIOD);
    }
    
    TMR1H = (unsigned char) (preload_value >> 8);
    TMR1L = (unsigned char) preload_value;

    // Toggle speaker pin to generate tone
    if (tmr1_RunCount < tmr1_TotalReqdCount) {
        tmr1_RunCount++;
        toneStep++;
        PORTBbits.RB3 = !PORTBbits.RB3; // Toggle the speaker

        // Update display periodically
        if (tmr1_RunCount % DISPLAY_UPDATE_PERIOD == 0) {
            dspTask_OnSevSeg();
        }
    } else {
        T1CONbits.TMR1ON = 0; // Stop timer when tone duration is complete
        PORTBbits.RB3 = 0;    // Ensure the speaker is off
        redLightCount = 0;    // Indicate the countdown is complete
    }
}
