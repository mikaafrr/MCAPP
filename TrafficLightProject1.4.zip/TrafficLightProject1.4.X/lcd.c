#include <xc.h>
#include "config.h"

#define LCD_DATA_D7         PORTDbits.RD3
#define LCD_DATA_D6         PORTDbits.RD2
#define LCD_DATA_D5         PORTDbits.RD1
#define LCD_DATA_D4         PORTDbits.RD0
#define LCD_RS              PORTEbits.RE1   	// RS signal for LCD
#define LCD_E               PORTEbits.RE0   	// E signal for LCD 

// Function Declarations:
// - In this file:
void lcdWriteCtrlWord(char x);
void lcdWriteDspData(char x);
void lcdWriteNibble(char nibble); 
void lcdCtrl_SetPos(unsigned char row, unsigned char col);
void lcdCtrl_FunctionSet(void);
void lcdCtrl_OnOffDisplay(char display_state, char cursor_state);
void lcdCtrl_SetEntryMode(void);
void lcdCtrl_ClearDisplay(void);
void lcdCreateCustomChars(void);
void displayStandingStickman(void);
void displayRightWalkStickman(void);
void displayLeftWalkStickman(void);
void displayGreenLightText(void);
void displayYellowLightText(void);
void displayRedLightText(void);
void clearLCD(void);

void initLCD(void)                      
{				 
    // Special Sequence a) to d) required for 4-bit interface 
    __delay_ms(15);         	   //  a) 15ms LCD power-up delay
    lcdWriteCtrlWord(0b00000011);  //  b) Function Set (DB4-DB7:8-bit interface)
    __delay_ms(5);		   //  c) 5ms delay
    lcdWriteCtrlWord(0b00000010);  //  d) Function Set (DB4-DB7:4-bit interface)    
	
    lcdCtrl_FunctionSet(); 	   //  Function Set - 4-bit, 2 lines, 5x7
    lcdCtrl_OnOffDisplay(1, 0);    //  Display on, cursor off
    lcdCtrl_SetEntryMode();	   //  Entry mode - inc addr, no shift
    lcdCtrl_ClearDisplay();	   //  Clear display & home position
}

void lcdWriteCtrlWord(char x) 
{     
    unsigned char upper_nibble, lower_nibble;
    
    upper_nibble = (x & 0b11110000) >> 4;
    lower_nibble = x & 0b00001111;
    
    LCD_RS = 0;
    lcdWriteNibble(upper_nibble);
    lcdWriteNibble(lower_nibble);
}

void lcdWriteDspData(char x) 
{     
    unsigned char upper_nibble, lower_nibble;
    
    upper_nibble = (x & 0b11110000) >> 4;
    lower_nibble = x & 0b00001111;
    
    LCD_RS = 1;
    lcdWriteNibble(upper_nibble);
    lcdWriteNibble(lower_nibble);
}

void lcdWriteNibble(char nibble) 
{
    LCD_DATA_D7 = (nibble & 0b00001000) >> 3;
    LCD_DATA_D6 = (nibble & 0b00000100) >> 2;
    LCD_DATA_D5 = (nibble & 0b00000010) >> 1;
    LCD_DATA_D4 = (nibble & 0b00000001);
    
    LCD_E       = 1;
    __delay_ms(1);
    LCD_E       = 0;
    __delay_ms(1);    
}

void lcdCtrl_SetPos(unsigned char row, unsigned char col) 
{
    unsigned char ramAddr;        // Ctrl instruction to be sent

    if (row == 1)                 // If row is 1:
        ramAddr = col - 1;        //   Subtract 1 from the col
    else                          // If row is 2:
        ramAddr = 0x40 + col - 1; //   Add 0x40 to ramAddr, and
                                  //   subtract 1 from the col

    lcdWriteCtrlWord(0x80 + ramAddr); // Add 0x80 to ramAddr and write 
                                  // ctrl instruction 
}

void lcdCtrl_FunctionSet(void) 
{
    lcdWriteCtrlWord(0b00101000);
}

void lcdCtrl_OnOffDisplay(char display_state, char cursor_state) 
{
    char pattern = 0b00001000;

    if(display_state == 1)
        pattern |= 0b00000100;    
    if(cursor_state == 1)
        pattern |= 0b00000011;

    lcdWriteCtrlWord(pattern);
}

void lcdCtrl_SetEntryMode(void) 
{
    lcdWriteCtrlWord(0b00000110);    
}

void lcdCtrl_ClearDisplay(void) 
{
    lcdWriteCtrlWord(0b00000001);    
}

void lcdCreateCustomChars(void) {
    unsigned char customStickMan1[8] = {
        0b01110,
        0b01110,
        0b00100,
        0b01110,
        0b10101,
        0b00100,
        0b01010,
        0b01010
    };
    
    unsigned char customStickMan2[8] = {
        0b01110,
        0b01110,
        0b00101,
        0b01110,
        0b10100,
        0b00100,
        0b01010,
        0b01010
    };
    
    
    unsigned char customStickMan3[8] = {
        0b01110,
        0b01110,
        0b10100,
        0b01110,
        0b00101,
        0b00100,
        0b01010,
        0b01010
    };
    
    unsigned char customCar2[8] = {
        0b00000,
        0b00000,
        0b11100,
        0b00010,
        0b00001,
        0b01111,
        0b01010,
        0b01110
    };
    unsigned char customCar1[8] = {
        0b00000,
        0b00000,
        0b01111,
        0b10000,
        0b10000,
        0b01111,
        0b01010,
        0b01110
    };
    
    unsigned char customStop[8] = {
        0b11100,
        0b11100,
        0b11100,
        0b11100,
        0b11100,
        0b00000,
        0b11100,
        0b11100
    };
    

    lcdWriteCtrlWord(0x40); // Set CGRAM address to 0
    for (int i = 0; i < 8; i++) {
        lcdWriteDspData(customStickMan1[i]);
    }
    
    lcdWriteCtrlWord(0x48); // Set CGRAM address to 1
    for (int i = 0; i < 8; i++){
        lcdWriteDspData(customCar1[i]);
    }
    
    lcdWriteCtrlWord(0x50); // Set CGRAM address to 2
    for (int i = 0; i < 8; i++){
        lcdWriteDspData(customCar2[i]);
    }
    
    lcdWriteCtrlWord(0x58);
    for (int i = 0; i < 8; i++){
        lcdWriteDspData(customStickMan2[i]);
    }
   
    lcdWriteCtrlWord(0x60);
    for (int i = 0; i < 8; i++){
        lcdWriteDspData(customStickMan3[i]);
    }   
    
    lcdWriteCtrlWord(0x68);
    for (int i = 0; i < 8; i++){
        lcdWriteDspData(customStop[i]);
    } 
}

void displayStandingStickman(void) {
    lcdCtrl_SetPos(1, 1); // Center position on the LCD
    lcdWriteDspData(0); // Display character at CGRAM address 0
    
    lcdCtrl_SetPos(2, 1); // Center position on the LCD
    lcdWriteDspData(1); // Display character at CGRAM address 1
    
    lcdCtrl_SetPos(2, 2); // Center position on the LCD
    lcdWriteDspData(2); // Display character at CGRAM address 2
}

void displayRightWalkStickman(void){
    lcdCtrl_SetPos(1, 1); // Center position on the LCD
    lcdWriteDspData(3); // Display character at CGRAM address 3
}

void displayLeftWalkStickman(void){
    lcdCtrl_SetPos(1, 1); // Center position on the LCD
    lcdWriteDspData(4); // Display character at CGRAM address 4   
}

void displayGreenLightText(void){
    char message1[] = "Dont Cross";
    char message2[] = "Cars Go";
    
    lcdCtrl_SetPos(1, 6);
    for(int i = 0; message1[i]!=0; i++) {
        lcdWriteDspData(message1[i]);
    }
    
    lcdCtrl_SetPos(2, 6);
    for(int i = 0; message2[i]!=0; i++) {
        lcdWriteDspData(message2[i]);
    }
}

void displayYellowLightText(void){
    char message3[] = "Dont Cross";
    char message4[] = "Cars Slow";
    
    lcdCtrl_SetPos(1, 6);
    for (int i = 0; message3[i] != 0; i++) {
        lcdWriteDspData(message3[i]);
    }

    lcdCtrl_SetPos(2, 6);
    for (int i = 0; message4[i] != 0; i++) {
        lcdWriteDspData(message4[i]);
    }
};

void displayRedLightText(void){
    char message5[] = "Cross";
    char message6[] = "Cars Stop";
    
    lcdCtrl_SetPos(1, 6);
    for (int i = 0; message5[i] != 0; i++) {
        lcdWriteDspData(message5[i]);
    }

    lcdCtrl_SetPos(2, 6);
    for (int i = 0; message6[i] != 0; i++) {
        lcdWriteDspData(message6[i]);
    }
    
    lcdCtrl_SetPos(2, 1); // Center position on the LCD
    lcdWriteDspData(1); // Display character at CGRAM address 1
    
    lcdCtrl_SetPos(2, 2); // Center position on the LCD
    lcdWriteDspData(2); // Display character at CGRAM address 2
    
    lcdCtrl_SetPos(2,3); // Center position on the LCD
    lcdWriteDspData(5); // Display character at CGRAM address 5
}

void clearLCD(void) {
    lcdCtrl_ClearDisplay();
}
